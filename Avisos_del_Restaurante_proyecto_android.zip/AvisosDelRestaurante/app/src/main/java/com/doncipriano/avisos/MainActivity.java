package com.doncipriano.avisos;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;

public class MainActivity extends Activity {
    private final String[] names = {"Cocina 1", "Cocina 2", "Barra", "Todas las impresoras"};
    private final String[] ips = {"192.168.1.13", "192.168.1.114", "192.168.1.12"};
    private Spinner printerSpinner;
    private EditText messageBox;
    private Button printButton;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF123F34);
        getWindow().setNavigationBarColor(0xFF123F34);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setBackgroundColor(0xFFF6F7F5);

        TextView title = new TextView(this);
        title.setText("AVISOS DEL RESTAURANTE");
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF173F35);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Mensajes rápidos a impresoras térmicas");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF66736D);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = matchWrap();
        subP.topMargin = dp(6);
        subP.bottomMargin = dp(28);
        root.addView(subtitle, subP);

        addLabel(root, "SELECCIONA IMPRESORA");
        printerSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names);
        printerSpinner.setAdapter(adapter);
        root.addView(printerSpinner, matchWrap());

        TextView ipHint = new TextView(this);
        ipHint.setText("Cocina 1 · 192.168.1.13:9100\nCocina 2 · 192.168.1.114:9100\nBarra · 192.168.1.12:9100");
        ipHint.setTextSize(12);
        ipHint.setTextColor(0xFF68756F);
        LinearLayout.LayoutParams hintP = matchWrap();
        hintP.topMargin = dp(8);
        hintP.bottomMargin = dp(24);
        root.addView(ipHint, hintP);

        addLabel(root, "ESCRIBE TU AVISO");
        messageBox = new EditText(this);
        messageBox.setGravity(Gravity.TOP | Gravity.START);
        messageBox.setText("Favor de revisar el área de cocina.");
        messageBox.setTextSize(17);
        messageBox.setMinLines(4);
        messageBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        messageBox.setBackgroundColor(0xFFFFFFFF);
        root.addView(messageBox, new LinearLayout.LayoutParams(-1, dp(140)));

        printButton = new Button(this);
        printButton.setText("IMPRIMIR AVISO");
        printButton.setTextSize(16);
        printButton.setAllCaps(false);
        LinearLayout.LayoutParams btnP = matchWrap();
        btnP.topMargin = dp(24);
        root.addView(printButton, btnP);

        status = new TextView(this);
        status.setText("Conéctate al Wi-Fi del restaurante para imprimir.");
        status.setTextSize(13);
        status.setTextColor(0xFF52635B);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusP = matchWrap();
        statusP.topMargin = dp(16);
        root.addView(status, statusP);

        TextView footer = new TextView(this);
        footer.setText("Impresión por red local · Puerto 9100");
        footer.setTextSize(11);
        footer.setTextColor(0xFF89938E);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footP = new LinearLayout.LayoutParams(-1, 0, 1);
        footP.gravity = Gravity.BOTTOM;
        root.addView(footer, footP);

        setContentView(root);

        printButton.setOnClickListener(v -> send());
    }

    private void send() {
        final String message = messageBox.getText().toString().trim();
        if (message.isEmpty()) {
            Toast.makeText(this, "Escribe un aviso primero.", Toast.LENGTH_SHORT).show();
            return;
        }
        final int selected = printerSpinner.getSelectedItemPosition();
        printButton.setEnabled(false);
        status.setText("Enviando aviso...");
        new Thread(() -> {
            String result;
            if (selected == 3) {
                int success = 0;
                StringBuilder errors = new StringBuilder();
                String[] labels = {"Cocina 1", "Cocina 2", "Barra"};
                for (int i = 0; i < ips.length; i++) {
                    try { printTo(ips[i], message); success++; }
                    catch (Exception e) { errors.append(labels[i]).append(": ").append(shortError(e)).append("  "); }
                }
                result = success == 3 ? "Aviso enviado a las 3 impresoras." :
                    "Enviado a " + success + " de 3. " + errors;
            } else {
                try {
                    printTo(ips[selected], message);
                    result = "Aviso enviado a " + names[selected] + ".";
                } catch (Exception e) {
                    result = "No se pudo imprimir: " + shortError(e);
                }
            }
            final String finalResult = result;
            runOnUiThread(() -> {
                status.setText(finalResult);
                printButton.setEnabled(true);
                Toast.makeText(this, finalResult, Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void printTo(String ip, String message) throws Exception {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ip, 9100), 3500);
            socket.setSoTimeout(3500);
            OutputStream out = socket.getOutputStream();
            out.write(new byte[]{0x1B, 0x40});                 // ESC @ initialize
            out.write(new byte[]{0x1B, 0x61, 0x01});          // center
            out.write(new byte[]{0x1B, 0x45, 0x01});          // bold on
            out.write("AVISO DEL RESTAURANTE\n".getBytes(Charset.forName("CP437")));
            out.write(new byte[]{0x1B, 0x45, 0x00});          // bold off
            out.write(new byte[]{0x1B, 0x61, 0x00});          // left
            out.write("--------------------------------\n".getBytes(Charset.forName("CP437")));
            out.write(message.getBytes(Charset.forName("CP437")));
            out.write("\n\n\n".getBytes(Charset.forName("CP437")));
            out.write(new byte[]{0x1D, 0x56, 0x00});          // full cut (if supported)
            out.flush();
        }
    }

    private String shortError(Exception e) {
        if (e instanceof java.net.ConnectException || e instanceof java.net.SocketTimeoutException)
            return "sin conexión al puerto 9100";
        return e.getMessage() == null ? "error de conexión" : e.getMessage();
    }
    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(12);
        label.setTypeface(null, Typeface.BOLD);
        label.setTextColor(0xFF52635B);
        LinearLayout.LayoutParams p = matchWrap();
        p.bottomMargin = dp(8);
        root.addView(label, p);
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
